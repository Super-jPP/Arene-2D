#pragma once
#include "math/vec2.hpp"
#include "ai/fsm/FSM.hpp"
#include "ai/fsm/IState.hpp"

#include <string>

struct Stats {
	float vitesse;
	float detectRadius;
	float lostRadius;
	float attackRange;
};

struct MemoireIa {
	Vec2 wanderDir;
	float wanderTimer;
	float spawnTimer;

	bool attackReady;
	bool didAttackThisFrame;


	AttackType attackType = AttackType::Light;
	AttackPhase attackPhase = AttackPhase::Windup;
	float phaseTimer = 0.f;

	float attackCooldownTimer = 0.f; 
	bool hitDone = false;
};


enum class AttackType { Light, Heavy, Dash };
enum class AttackPhase { Windup, Active, Recovery };

struct DummyOwner {
	Vec2 pos;
	Vec2 playerPos;
	float hp;
	Stats stats;
	MemoireIa memoireIa;
	std::string debugStateName;
	ai::fsm::FSM<DummyOwner>* fsm = nullptr;
	std::string animState;



	Vec2 getPos() const {
		return pos;
	};

	Vec2 getPlayerPos() const {
		return playerPos;
	};
	
	float getHP() const {
		return hp;
	};

	const Stats& getStats() const {
		return stats;
	};

	void setDebugStateName(const std::string& name) {
		debugStateName = name;
	}
	
	void moveToward(const Vec2& target, float dt) {
		Vec2 dir = (target - pos).normalized();
		pos = pos + dir * stats.vitesse * dt;
	}

	void requestAttack() {
		memoireIa.didAttackThisFrame = true;
		memoireIa.attackReady = false;

		
		memoireIa.attackCooldownTimer = 0.6f;
	}


	void resetFrameFlags() {
		memoireIa.didAttackThisFrame = false;
	}

	void moveDir(const Vec2& direction, float dt)
	{
		if (direction.x == 0.f && direction.y == 0.f)
			return;
		Vec2 dir = direction.normalized();
		pos = pos + dir * stats.vitesse * dt;
	}

	void bindFSM(ai::fsm::FSM<DummyOwner>& f)
	{
		fsm = &f;
	}

	void changeState(ai::fsm::IState<DummyOwner>& next)
	{
		if (!fsm) return; 
		fsm->changeState(next, *this);
	}

	bool attackReady() const {
		return memoireIa.attackReady;
	}

	void setAnimState(const std::string& s) {
		animState = s;
	}

	void updateCooldown(float dt) {
		if (!memoireIa.attackReady) {
			memoireIa.attackCooldownTimer -= dt;
			if (memoireIa.attackCooldownTimer <= 0.f) {
				memoireIa.attackCooldownTimer = 0.f;
				memoireIa.attackReady = true;
			}
		}
	}

};

