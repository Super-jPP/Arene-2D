#pragma once
class EntityId
{
};

