#pragma once

#include "ai/fsm/IState.hpp"
#include <string>


template <typename Owner>
class EnemyChase;

struct AttackDef
{
    const char* animBase;
    float windup;
    float active;
    float recovery;
    float cooldown;
};

inline AttackDef getAttackDef(AttackType t)
{
    switch (t)
    {
    case AttackType::Heavy: return { "AttackHeavy", 0.18f, 0.06f, 0.25f, 0.9f };
    case AttackType::Dash:  return { "AttackDash",  0.12f, 0.05f, 0.20f, 0.8f };
    case AttackType::Light:
    default:               return { "AttackLight", 0.10f, 0.05f, 0.18f, 0.6f };
    }
}

inline const char* phaseSuffix(AttackPhase p)
{
    switch (p)
    {
    case AttackPhase::Windup:   return "_Windup";
    case AttackPhase::Active:   return "_Active";
    case AttackPhase::Recovery: return "_Recovery";
    default:                    return "";
    }
}

template <typename Owner>
class EnemyAttack : public ai::fsm::IState<Owner>
{
public:
    static EnemyAttack& instance()
    {
        static EnemyAttack s;
        return s;
    }

    const char* name() const override { return "Attack"; }

    void onEnter(Owner& owner) override
    {
        owner.setDebugStateName("Attack");

        owner.memoireIa.attackPhase = AttackPhase::Windup;
        owner.memoireIa.phaseTimer = getAttackDef(owner.memoireIa.attackType).windup;
        owner.memoireIa.hitDone = false;

        // animation state (neutre, renderer fera le mapping)
        const AttackDef def = getAttackDef(owner.memoireIa.attackType);
        owner.setAnimState(std::string(def.animBase) + phaseSuffix(owner.memoireIa.attackPhase));
    }

    void onUpdate(Owner& owner, float dt) override
    {
        AttackDef def = getAttackDef(owner.memoireIa.attackType);

        owner.memoireIa.phaseTimer -= dt;

        // Phase switching
        if (owner.memoireIa.attackPhase == AttackPhase::Windup)
        {
            if (owner.memoireIa.phaseTimer <= 0.f)
            {
                owner.memoireIa.attackPhase = AttackPhase::Active;
                owner.memoireIa.phaseTimer = def.active;
                owner.setAnimState(std::string(def.animBase) + phaseSuffix(owner.memoireIa.attackPhase));
            }
        }
        else if (owner.memoireIa.attackPhase == AttackPhase::Active)
        {
            // hit window: d�clenche UNE FOIS
            if (!owner.memoireIa.hitDone)
            {
                owner.requestAttack();
                // on �crase le cooldown par celui de l�attaque choisie
                owner.memoireIa.attackCooldownTimer = def.cooldown;
                owner.memoireIa.hitDone = true;
            }

            if (owner.memoireIa.phaseTimer <= 0.f)
            {
                owner.memoireIa.attackPhase = AttackPhase::Recovery;
                owner.memoireIa.phaseTimer = def.recovery;
                owner.setAnimState(std::string(def.animBase) + phaseSuffix(owner.memoireIa.attackPhase));
            }
        }
        else // Recovery
        {
            if (owner.memoireIa.phaseTimer <= 0.f)
            {
                // fin d'attaque => retour en chase
                owner.changeState(EnemyChase<Owner>::instance());
                return;
            }
        }
    }

    void onExit(Owner&) override {}
};
