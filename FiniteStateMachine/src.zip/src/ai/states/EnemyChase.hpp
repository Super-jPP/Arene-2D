#pragma once

#include "ai/fsm/IState.hpp"
#include "math/vec2.hpp"



template <typename Owner>
class EnemyWander;
template <typename Owner>
class EnemyAttack;
template <typename Owner>
class EnemyChase : public ai::fsm::IState<Owner>
{
public: 
    static EnemyChase& instance()
    {
        static EnemyChase s;
        return s;
    }

    const char* name() const override
    {
        return "Chase";
    }

    void onEnter(Owner& owner) override
    {
        owner.setDebugStateName("Chase");
    }

    void onUpdate(Owner& owner, float dt) override
    {
        const float dist = Vec2::distance(owner.getPos(), owner.getPlayerPos());

        if (dist > owner.getStats().lostRadius)
        {
            owner.changeState(EnemyWander<Owner>::instance());
            return;
        }
       
        if (owner.attackReady() && dist <= owner.getStats().attackRange)
        {
            if (dist <= owner.getStats().attackRange * 0.40f)
                owner.memoireIa.attackType = AttackType::Heavy;
            else if (dist <= owner.getStats().attackRange * 0.85f)
                owner.memoireIa.attackType = AttackType::Dash;
            else
                owner.memoireIa.attackType = AttackType::Light;

            owner.changeState(EnemyAttack<Owner>::instance());
            return;
        }

        owner.moveToward(owner.getPlayerPos(), dt);
    }

    void onExit(Owner&) override
    {
        
    }
};
